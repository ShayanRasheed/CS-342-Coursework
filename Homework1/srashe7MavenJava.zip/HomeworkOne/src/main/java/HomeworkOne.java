
/*
 * This class will eventually contain the user interface
 */
public class HomeworkOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}
}
